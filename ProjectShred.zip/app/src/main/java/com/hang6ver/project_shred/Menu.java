package com.hang6ver.project_shred;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.SimpleAdapter;

public class Menu extends AppCompatActivity {
    Button yoga, health, trainer, fat, body;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);

        yoga = (Button)findViewById(R.id.yoga);
        body = (Button)findViewById(R.id.bodyBuild);
        health = (Button)findViewById(R.id.health_diet);
        fat = (Button)findViewById(R.id.fatBurn);
        trainer = (Button)findViewById(R.id.trainer);

        body.setOnClickListener(new startBody());
        yoga.setOnClickListener(new startYoga());
        health.setOnClickListener(new startHealth());
        fat.setOnClickListener(new startFat());
        trainer.setOnClickListener(new startTrainer());

    }

    class startBody implements View.OnClickListener{

        public void onClick(View v){
            Intent in = new Intent(Menu.this, bodyBuilding.class);
            startActivity(in);

        }
    }

    class startYoga implements View.OnClickListener{
        public void onClick(View v){
            Intent in = new Intent(Menu.this, Yoga.class);
            startActivity(in);

        }
    }

    class startHealth implements View.OnClickListener{
        public void onClick(View v){
            Intent in = new Intent(Menu.this, Health_Diet.class);
            startActivity(in);

        }
    }
    class startFat implements View.OnClickListener{
        public void onClick(View v){
            Intent in = new Intent(Menu.this, FatBurn.class);
            startActivity(in);

        }
    }
    class startTrainer implements View.OnClickListener{
        public void onClick(View v){
            Intent in = new Intent(Menu.this, Trainer.class);
            startActivity(in);

        }
    }
}
