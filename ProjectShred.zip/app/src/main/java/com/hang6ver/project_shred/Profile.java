package com.hang6ver.project_shred;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class Profile extends AppCompatActivity {

    TextView name, age, weight, height, bmi, workoutDays, gender, type;
    Button workout;
    String workDays;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);


        workout = (Button) findViewById(R.id.workout);
        Intent in = getIntent();

        name = (TextView) findViewById(R.id.name);
        age = (TextView) findViewById(R.id.age);
        weight = (TextView) findViewById(R.id.weight);
        height = (TextView) findViewById(R.id.height);
        bmi = (TextView) findViewById(R.id.bmi);
        workoutDays = (TextView) findViewById(R.id.workoutDays);
        gender = (TextView) findViewById(R.id.gender);
        type = (TextView) findViewById(R.id.type);

        String fileName = in.getStringExtra("fileName");

        Intent in2 = new Intent(Profile.this, WorkoutDays.class);


        try {
            InputStream inputStream = openFileInput(fileName);

            if (inputStream != null) {
                Log.d("fileTest", "File FOUnd");
                InputStreamReader inputStreamReader = new InputStreamReader(inputStream);
                BufferedReader bufferedReader = new BufferedReader(inputStreamReader);

                String str;


                    name.setText(str  = bufferedReader.readLine());
                    str = str = bufferedReader.readLine();
                    age.setText("Age: "+(str = bufferedReader.readLine()) +"");
                    weight.setText("Weight: "+(str = bufferedReader.readLine()));
                    height.setText("Height: "+(str = bufferedReader.readLine()));
                    bmi.setText("BMI Number: "+(str = bufferedReader.readLine()));

                    workoutDays.setText("Workout days: "+(str = bufferedReader.readLine()));
                    workDays = str;
                    gender.setText("Gender: "+(str = bufferedReader.readLine()));
                    type.setText("Type: "+(str = bufferedReader.readLine()));

            }
            else
                Log.d("fileTest", "File Not Found");

        } catch (IOException e) {
            e.printStackTrace();
            Log.d("fileTest", "File Doesnt Exist");
        }

        workout.setOnClickListener( new startWorkoutPlan());
    }


    class startWorkoutPlan implements View.OnClickListener{

        public void onClick(View v){
            Intent in = new Intent(Profile.this, WorkoutDays.class);
            in.putExtra("workoutDays" ,workDays);
            startActivity(in);

        }
    }


}
