package com.hang6ver.project_shred;

import android.content.Intent;
import android.content.res.AssetManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.Array;
import java.util.ArrayList;

public class Trainer extends AppCompatActivity {
    String str;
    Button registration;
    ListView listDisp;
    ArrayList<String> nameLIst = new ArrayList<String>();
    ArrayList<Integer>progList = new ArrayList<Integer>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_trainer);
        listDisp = (ListView)findViewById(R.id.listDisp);
        registration = (Button)findViewById(R.id.registration);
        registration.setOnClickListener(new startRegistration());

        AssetManager am = getAssets();

        try {

            InputStream is = openFileInput("user.txt");
            if( is != null){
                BufferedReader text = new BufferedReader(new InputStreamReader(is));
                while ((str = text.readLine()) != null) {
                    nameLIst.add(str);
                }

                final ArrayAdapter<String> list = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, nameLIst);
                listDisp.setAdapter(list);


                class select implements AdapterView.OnItemClickListener{

                    public void onItemClick(AdapterView<?>adapter, View v, int position, long id){
                        Log.d("fileRead", "Item Clicked");
                        Log.d("fileRead", position +"");
                        String output = nameLIst.get(position);

                        Log.d("testName", nameLIst.get(position));
                        Log.d("testName", "indira Gandhi");
                        try {
                            InputStream inputStream = openFileInput("indira Gandhi");

                            if (inputStream != null) {
                                Log.d("fileRead", "File FOUnd");
                                InputStreamReader inputStreamReader = new InputStreamReader(inputStream);
                                BufferedReader bufferedReader = new BufferedReader(inputStreamReader);

                                String str;

                                while ((str = bufferedReader.readLine()) != null) {
                                    Log.d("fileRead", str);
                                }
                            }
                            else
                                Log.d("fileRead", "File Not FOUnd");

                        } catch (IOException e) {
                            e.printStackTrace();
                            Log.d("fileRead", "File Doesnt Exist");
                        }

                        Intent in = new Intent(Trainer.this, Profile.class);
                        in.putExtra("fileName" ,nameLIst.get(position));
                        startActivity(in);
                    }

                }
                listDisp.setOnItemClickListener(new select());

            }
            else{
                Log.d("OUT","File Not created");
            }


        }catch ( IOException e){
            e.printStackTrace();
        }
    }
    class startRegistration implements View.OnClickListener{

        public void onClick(View v){
            Intent in = new Intent(Trainer.this, NewUser.class);
            startActivity(in);

        }
    }



}
