package com.hang6ver.project_shred;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Health_Diet extends AppCompatActivity {

    Button health, diet;
    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_health__diet);

        health = (Button)findViewById(R.id.health);
        diet = (Button)findViewById(R.id.diet);

        health.setOnClickListener(new startHealth());
        diet.setOnClickListener(new startDiet());
    }

    class startHealth implements View.OnClickListener{

        public void onClick(View v){
            Intent in = new Intent(Health_Diet.this, excercise_Menu.class);
            in.putExtra("fileName","chest.txt");
            startActivity(in);

        }
    }

    class startDiet implements View.OnClickListener{

        public void onClick(View v){
            Intent in = new Intent(Health_Diet.this, excercise_Menu.class);
            in.putExtra("fileName","chest.txt");
            startActivity(in);

        }
    }
}
