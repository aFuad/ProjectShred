package com.hang6ver.project_shred;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.IntegerRes;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;


public class ResultScreen extends AppCompatActivity {
    String userName, userAge, userBMI, userWeight, userHeight, userDays, userGender, ques, rd1, rd2, type, answer = null, userType;
    String fileName;
    Button finish;
    RadioGroup btnBox;
    RadioButton rdb1, rdb2, result;
    TextView quest, disp;
    Button proceed;
    int quesType, finalChoice;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result_screen);

        Intent in = getIntent();



        finish = (Button) findViewById(R.id.proceed);
        rdb1 = (RadioButton) findViewById(R.id.rd1);
        rdb2 = (RadioButton) findViewById(R.id.rd2);
        quest = (TextView) findViewById(R.id.quest);
        disp = (TextView) findViewById(R.id.disp);

        btnBox = (RadioGroup) findViewById((R.id.btnBox));

        userName = in.getStringExtra("Name");
        userGender = in.getStringExtra("Gender");
        userAge = in.getStringExtra("Age");
        userWeight = in.getStringExtra("Weight");
        userHeight = in.getStringExtra("Height");
        userDays = in.getStringExtra("Days");
        ques = in.getStringExtra("Quest");
        rd1 = in.getStringExtra("Rd1");
        rd2 = in.getStringExtra("Rd2");
        type = in.getStringExtra("Type");
        userBMI = in.getStringExtra("BMI");
        quesType = Integer.parseInt(type);
        fileName = in.getStringExtra("fileName");

        //Log.d("Test",rd1);

        rdb1.setText(rd1);
        rdb2.setText(rd2);



        quest.setText(ques);
        proceed = (Button) findViewById(R.id.proceed);
        proceed.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                 int selection = btnBox.getCheckedRadioButtonId();
                result = (RadioButton) findViewById(selection);

                answer = result.getText().toString();

                processResult( answer);

                //use finalchoice to call workout(from 1 to 5 based on lexiograpgic order od type)

            }
        });
    }

    public void processResult(String answer){
        if( quesType == 1){
            if( answer.equalsIgnoreCase("Highly Flexible")){
                //choose bodyB or yoga
                quest.setText("Please choose one: ");
                rdb1.setText("Yoga");
                rdb2.setText("BodyBuilding");
                quesType = 11;
            }

            else{
                //bodyb
                finalChoice = 1;
                callIntent();
            }
        }

        else if( quesType == 2){
            if( answer.equalsIgnoreCase("Yes")) {
                //bodyb&cardio
                finalChoice = 2;
                callIntent();
            }

            else{
                //bodyb
                finalChoice = 1;
                callIntent();
            }
        }

        else if( quesType == 3){
            if( answer.equalsIgnoreCase("Highly Flexible")){
                //store questype
                quest.setText("Would you like to like to lose weight?");
                rdb1.setText("Yes");
                rdb2.setText("No");
                quesType = 31;
            }

            else{
                quest.setText("Would you like to like to lose weight?");
                rdb1.setText("Yes");
                rdb2.setText("No");
                quesType = 32;
            }
        }

        else if( quesType == 11){
            if( answer.equalsIgnoreCase("Yoga")){
                //yoga
                finalChoice = 5;
                callIntent();
            }

            else
                //bodyb
                finalChoice = 1;
                callIntent();
        }

        else if( quesType == 31){
            if( answer.equalsIgnoreCase("Yes")){
                //cardio&yoga
                finalChoice = 4;
                callIntent();
            }

            else{
                quest.setText("Please choose one: ");
                rdb1.setText("Yoga");
                rdb2.setText("BodyBuilding");
                quesType = 312;
            }
        }

        else if( quesType == 32){
            if( answer.equalsIgnoreCase("Yes")) {
                //bodyb&cardio
                finalChoice = 2;
                callIntent();
            }

            else{
                //bodyb
                finalChoice = 1;
                callIntent();
            }
        }

        else if( quesType == 312) {
            if (answer.equalsIgnoreCase("Yoga")) {
                //yoga
                finalChoice = 5;
                callIntent();
            }
            else{
                //bodyb
                finalChoice = 1;
                callIntent();
            }
        }
    }

    public void callIntent(){
        Intent in = new Intent(ResultScreen.this, Trainer.class);


        Log.d("fileName", fileName);

        File file = getFileStreamPath(fileName);
        try {
            if (!file.exists()) {
                file.createNewFile();
            }

            FileOutputStream writer = openFileOutput(file.getName(), Context.MODE_APPEND);
            userName = userName + "\n";
            writer.write(userName.getBytes());
            userAge = userAge + "\n";
            writer.write(userAge.getBytes());
            userWeight = userWeight + "\n";
            writer.write(userWeight.getBytes());
            userHeight = userHeight + "\n";
            writer.write(userHeight.getBytes());
            userBMI = userBMI + "\n";
            writer.write(userBMI.getBytes());
            userDays = userDays + "\n";
            writer.write(userDays.getBytes());
            userGender = userGender + "\n";
            writer.write(userGender.getBytes());
            userType = finalChoice+ "" + "\n";
            writer.write(userType.getBytes());
            writer.flush();
            Log.d("filePath", file.getAbsolutePath());
            writer.close();

            startActivity(in);

        } catch (IOException e) {
            e.printStackTrace();
        }

    }


}

