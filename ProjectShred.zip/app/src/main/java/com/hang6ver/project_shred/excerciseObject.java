package com.hang6ver.project_shred;

import java.util.ArrayList;
import java.util.StringTokenizer;

/**
 * Created by qwuad on 7/18/2016.
 */
public class excerciseObject {
    String title;
    int numOfExcercise;
    ArrayList <Instruction> instList = new ArrayList<Instruction>();

    public excerciseObject( String name){
        title = name;
        numOfExcercise = 0;
    }

    void addInst (String instName, String description){
        instList.add( new Instruction (instName, description));
        numOfExcercise++;
    }



}

class Instruction{
    String instName, description;
    public Instruction(String inName, String des){
        instName = inName;
        description = des;
    }
}


