package com.hang6ver.project_shred;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class FatBurn extends AppCompatActivity {

    Button mild, moderate, vigorous;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fat_burn);

        mild = (Button)findViewById(R.id.mild);
        moderate = (Button)findViewById(R.id.moderate);
        vigorous = (Button)findViewById(R.id.vigorous);

        mild.setOnClickListener(new startMild());
        moderate.setOnClickListener(new startModerate());
        vigorous.setOnClickListener(new startVigorous());
    }
    class startMild implements View.OnClickListener{

        public void onClick(View v){
            Intent in = new Intent(FatBurn.this, excercise_Menu.class);
            in.putExtra("fileName","chest.txt");
            startActivity(in);

        }
    }

    class startModerate implements View.OnClickListener{

        public void onClick(View v){
            Intent in = new Intent(FatBurn.this, excercise_Menu.class);
            in.putExtra("fileName","chest.txt");
            startActivity(in);

        }
    }

    class startVigorous implements View.OnClickListener{

        public void onClick(View v){
            Intent in = new Intent(FatBurn.this, excercise_Menu.class);
            in.putExtra("fileName","chest.txt");
            startActivity(in);

        }
    }

}
