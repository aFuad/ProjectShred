package com.hang6ver.project_shred;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class bodyBuilding extends AppCompatActivity {
    Button chest, back, shoulder, bicep, tricep, legs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_body_building);

        chest = (Button)findViewById(R.id.chest);
        back = (Button)findViewById(R.id.back);
        shoulder = (Button)findViewById(R.id.shoulder);
        bicep = (Button)findViewById(R.id.bicep);
        tricep = (Button)findViewById(R.id.tricep);
        legs = (Button)findViewById(R.id.legs);

        chest.setOnClickListener(new startChest());
        back.setOnClickListener(new startBack());
        shoulder.setOnClickListener(new startShoulder());
        bicep.setOnClickListener(new startBicep());
        tricep.setOnClickListener(new startTricep());
        legs.setOnClickListener(new startLegs());
    }

    class startChest implements View.OnClickListener{

        public void onClick(View v){
           Intent in = new Intent(bodyBuilding.this, excercise_Menu.class);
            in.putExtra("fileName","chest.txt");
            startActivity(in);

        }
    }

    class startBack implements View.OnClickListener{

        public void onClick(View v){
            Intent in = new Intent(bodyBuilding.this, excercise_Menu.class);
            in.putExtra("fileName","back.txt");
            startActivity(in);

        }
    }

    class startShoulder implements View.OnClickListener{

        public void onClick(View v){
            Intent in = new Intent(bodyBuilding.this, excercise_Menu.class);
            in.putExtra("fileName","shoulder.txt");
            startActivity(in);

        }
    }

    class startBicep implements View.OnClickListener{

        public void onClick(View v){
            Intent in = new Intent(bodyBuilding.this, excercise_Menu.class);
            in.putExtra("fileName","biceps.txt");
            startActivity(in);

        }
    }

    class startTricep implements View.OnClickListener{

        public void onClick(View v){
            Intent in = new Intent(bodyBuilding.this, excercise_Menu.class);
            in.putExtra("fileName","triceps.txt");
            startActivity(in);

        }
    }
    class startLegs implements View.OnClickListener{

        public void onClick(View v){
            Intent in = new Intent(bodyBuilding.this, excercise_Menu.class);
            in.putExtra("fileName","legs.txt");
            startActivity(in);

        }
    }
}
