package com.hang6ver.project_shred;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;
import android.view.View.OnClickListener;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class NewUser extends AppCompatActivity {
    String userName = " ", userAge = " ", userWeight = " ", userHeight = " ", userDays= " ", userBMI;
    String fileName;
    EditText name, age, weight, height, days;
    RadioButton gender;
    RadioGroup btnBox;
    String userGender;
    CheckBox diesease;
    Button done;
    int selection = -100;
    double bmiResult;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_user);

        name = (EditText)findViewById(R.id.name);
        age = (EditText)findViewById(R.id.age);
        weight = (EditText)findViewById(R.id.weight);
        height = (EditText)findViewById(R.id.height);
        days = (EditText)findViewById(R.id.daysToWorkout);
        btnBox = (RadioGroup)findViewById(R.id.btnBox);

        selection = btnBox.getCheckedRadioButtonId();
        gender = (RadioButton) findViewById(selection);

        done = (Button)findViewById(R.id.regNew);
        done.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                int selectedId = btnBox.getCheckedRadioButtonId();
                gender = (RadioButton) findViewById(selectedId);

                userGender = gender.getText().toString();
                fileName = name.getText().toString();
                userName = name.getText().toString() + "\n";

                userAge = age.getText().toString();
                userWeight = weight.getText().toString();
                userHeight = height.getText().toString();
                userDays = days.getText().toString();

                if ((userName == " ") || (userAge == " ") || (userWeight == " ") || (userHeight == " ") || (userDays == " ")) {
                    Toast.makeText(NewUser.this, "Please ensure that all fields are filled",
                            Toast.LENGTH_LONG).show();
                } else if ((Integer.parseInt(userDays) > 3) || (Integer.parseInt(userDays) < 1)) {
                    Toast.makeText(NewUser.this, "Please ensure number of workout days is from 1 to 3",
                            Toast.LENGTH_LONG).show();
                } else {




                    File file = getFileStreamPath("user.txt");
                    try {
                        if (!file.exists()) {
                            file.createNewFile();
                        }

                        FileOutputStream writer = openFileOutput(file.getName(), Context.MODE_APPEND);

                        writer.write(userName.getBytes());
                        writer.flush();
                        Log.d("Out", "File created");
                        writer.close();

                    } catch (IOException e) {
                        e.printStackTrace();
                    }

                    try {
                        InputStream inputStream = openFileInput("user.txt");

                        if (inputStream != null) {
                            InputStreamReader inputStreamReader = new InputStreamReader(inputStream);
                            BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
                            String receiveString = "";
                            StringBuilder stringBuilder = new StringBuilder();

                            String str;

                            while ((str = bufferedReader.readLine()) != null) {
                                Log.d("Out", str);
                            }
                        }

                    } catch (IOException e) {
                        e.printStackTrace();
                    }


                    Intent in = new Intent(NewUser.this, ResultScreen.class);
                    in.putExtra("Gender", userGender);
                    in.putExtra("Name", userName);
                    in.putExtra("Age", userAge);
                    in.putExtra("Weight", userWeight);
                    in.putExtra("Height", userHeight);
                    in.putExtra("Days", userDays);
                    in.putExtra("fileName", fileName);


                    bmiResult = BMICalculator(Double.parseDouble(userWeight), Double.parseDouble(userHeight));
                    userBMI = bmiResult +"";
                    in.putExtra("BMI", userBMI);
                 //   Log.d("debug", "" + bmiResult );

                    if (bmiResult < 18.5) {
                        in.putExtra("Quest", "How flexible are you?");
                        in.putExtra("Rd1", "Highly Flexible");
                        in.putExtra("Rd2", "Not Very Flexible");
                        in.putExtra("Type", "1");
                    } else if (bmiResult > 25) {
                        in.putExtra("Quest", "Would you like to like to lose weight?");
                        in.putExtra("Rd1", "Yes");
                        in.putExtra("Rd2", "No");
                        in.putExtra("Type", "2");

                    } else {
                        in.putExtra("Quest", "How flexible are you?");
                        in.putExtra("Rd1", "Highly Flexible");
                        in.putExtra("Rd2", "Not Very Flexible");
                        in.putExtra("Type", "3");
                    }

                    startActivity(in);

                }
        }

        });


    }

    public double BMICalculator (double weight, double height){
        double BMI= weight/Math.pow( height/100,2);
        return BMI;
    }

    class startResultScreen implements View.OnClickListener{

        public void onClick(View v){
            Intent in = new Intent(NewUser.this, ResultScreen.class);
            startActivity(in);

        }
    }

}
