package com.hang6ver.project_shred;

import android.content.Intent;
import android.content.res.AssetManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class excercise_Menu extends AppCompatActivity {
    String fileName, str;
    ArrayList<String> instList = new ArrayList<String>();
    ArrayList<String> descriptionList = new ArrayList<String>();
    ArrayList<String[]> imgListArr = new ArrayList<String[]>();
    String [] imgList = new String[3];
    ListView listDisp;
    int count;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_excercise__menu);
        Intent in = getIntent();
        listDisp = (ListView)findViewById(R.id.listView);
        count = 0;
        fileName = in.getStringExtra("fileName");
        AssetManager am = getAssets();

        try{

            InputStream is = am.open(fileName);
            BufferedReader text = new BufferedReader( new InputStreamReader( is));

            while( (str = text.readLine()) != null ){
                Log.d("looping","looping");
                instList.add(str);
                while( (!(str = text.readLine()).equals("."))){
                    imgList[count] = str;
                    count++;
                }
                imgListArr.add(imgList);
                str = text.readLine();
                descriptionList.add( (str = text.readLine()));
            }

            final ArrayAdapter<String> list = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,instList);
            listDisp.setAdapter(list);

            class select implements AdapterView.OnItemClickListener{

                public void onItemClick(AdapterView<?>adapter, View v, int position, long id){

                    Intent in = new Intent(excercise_Menu.this, DescriptionView.class);
                    in.putExtra("Description",descriptionList.get(position));
                    startActivity(in);

                }

            }

            listDisp.setOnItemClickListener(new select());


        }catch( IOException e){
            e.printStackTrace();
        }
    }
}
