package com.hang6ver.project_shred;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class WorkoutDays extends AppCompatActivity {

    Button day1, day2, day3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_workout_days);


        Intent in = getIntent();
        String workoutDaysfor = in.getStringExtra("workoutDays");
        int workoutDays= Integer.parseInt(workoutDaysfor);
        day1 = (Button)findViewById(R.id.day1);
        day2 = (Button)findViewById(R.id.day2);
        day3 = (Button)findViewById(R.id.day3);

        day1.setOnClickListener(new startDay1());
        day2.setOnClickListener(new startDay2());
        day3.setOnClickListener(new startDay3());

        if(workoutDays==1){
            day2.setEnabled(false);
            day3.setEnabled(false);
        }
        if(workoutDays==2){
            day3.setEnabled(false);
        }


    }

    class startDay1 implements View.OnClickListener{

        public void onClick(View v){
            Intent in = new Intent(WorkoutDays.this, excercise_Menu.class);
            in.putExtra("fileName","day1.txt");
            startActivity(in);

        }
    }

    class startDay2 implements View.OnClickListener{

        public void onClick(View v){
            Intent in = new Intent(WorkoutDays.this, excercise_Menu.class);
            in.putExtra("fileName","day1.txt");
            startActivity(in);

        }
    }

    class startDay3 implements View.OnClickListener{

        public void onClick(View v){
            Intent in = new Intent(WorkoutDays.this, excercise_Menu.class);
            in.putExtra("fileName","day1.txt");
            startActivity(in);

        }
    }
}
