package com.hang6ver.project_shred;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Yoga extends AppCompatActivity {

    Button beginner, intermediate, advanced;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_yoga);

        beginner = (Button)findViewById(R.id.beginner);
        intermediate = (Button)findViewById(R.id.intermediate);
        advanced = (Button)findViewById(R.id.advanced);

        beginner.setOnClickListener(new startBeginner());
        intermediate.setOnClickListener(new startIntermediate());
        advanced.setOnClickListener(new startAdvanced());
    }

    class startBeginner implements View.OnClickListener{

        public void onClick(View v){
            Intent in = new Intent(Yoga.this, excercise_Menu.class);
            in.putExtra("fileName","chest.txt");
            startActivity(in);

        }
    }

    class startIntermediate implements View.OnClickListener{

        public void onClick(View v){
            Intent in = new Intent(Yoga.this, excercise_Menu.class);
            in.putExtra("fileName","chest.txt");
            startActivity(in);

        }
    }

    class startAdvanced implements View.OnClickListener{

        public void onClick(View v){
            Intent in = new Intent(Yoga.this, excercise_Menu.class);
            in.putExtra("fileName","chest.txt");
            startActivity(in);

        }
    }
}
